## Maps

    let markers = [
      {lat: 37.773972, lng: -122.431297, title: 'San Francisco'}
    ];
    <MapComponent markers={markers}
        zoom={9} />

A Google map
