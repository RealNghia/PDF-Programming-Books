# Credits

Thanks to @taion and the community for their work on [relay-todomvc](https://github.com/taion/relay-todomvc), on which some of the structure of this project is based.

The book style design is from the Codrops Article [3D Book Showcase](https://tympanus.net/Development/3DBookShowcase/) by [Mary Lou](https://twitter.com/crnacura)
